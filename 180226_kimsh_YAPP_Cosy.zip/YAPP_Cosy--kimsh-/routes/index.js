var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/MainPage', function(req, res){
  res.render('MainPage.ejs');
});

router.get('/LoginPage', function(req, res){
    res.render('LoginPage.ejs');
});

router.get('/RegPage', function(req, res){
  res.render('RegPage.ejs');
});

router.get('/SearchPage', function(req, res){
    res.render('SearchPage.ejs');
});

/*router.route('/ActivePage').get(function(req, res){
    res.render('ActivePage.ejs');
});*/

router.get('/ActivePage', function(req, res){
    res.render('ActivePage.ejs');
});

module.exports = router;
